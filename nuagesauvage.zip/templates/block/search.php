<div class="search-new-page w-100">
    <form action="<?php echo get_home_url() ?>" class="w-100 h-100">
        <input name="s" autocomplete="off" class="form-control input-section-new" type="text" placeholder="Cherchez...">
        <button class="btn" type="submit">
            <i class="fas fa-search search-icon"></i>
        </button>
    </form>
</div>