<section class="home_section4">
    <div class="section4-home">
        <div class="home-img">
            <img src="	https://nuagesauvage.fr/wp-content/uploads/2022/12/banner-chinh-1-scaled-e166988727-1.jpg" alt="">
        </div>
        <div class="container">
            <div class="item-video">
                <a class="video-gallery" data-fancybox="gallery" href="https://youtu.be/37Rsolrkjko">
                    <img src="	https://nuagesauvage.fr/wp-content/uploads/2022/12/anhclip-1-scaled-1.jpg" alt="">
                    <span></span>
                </a>
            </div>
        </div>
    </div>
</section>