<section class="section__breadcrumb">
    <div class="container">
        <?php the_breadcrumb(); ?>
    </div>
</section>