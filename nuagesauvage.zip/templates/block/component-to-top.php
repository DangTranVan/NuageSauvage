<a href="#" class="button-to-top">
    <div id="bottom_to_top">
        <i class="fal fa-chevron-up"></i>
    </div>
</a>
<!-- <style>
    #bottom_to_top {
        display: flex;
        justify-content: center;
        align-items: center;
        position: fixed;
        z-index: 10;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: transparent;
        /* border: 2px solid $main-color;
        color: $main-color; */
        bottom: -100px;
        right: 30px;
        transition: 0.3s ease;

    }

    #bottom_to_top:hover {
        background: #00ca71;
        border: 2px solid #00ca71;
        color: white;
    }

    @media screen and (max-width: 576px) {
        #bottom_to_top {
            right: 15px !important;
        }
    }
</style> -->