<section class="home_section7">
    <div class="section7-gt-wrap">
        <div class="wrap-benner">
            <div class="container">
                <div class="content">
                    <h2 class="text-white text-center mb-lg-2 mb-3">NOS THÉS SONT PRÉVENUS DE LA PERMACULTURE, DE L’AGROFORESTERIE <br> OU DE L'AGRICULTURE BIOLOGIQUE DU VIETNAM</h2>
                    <p class="text-white text-center mb-lg-4 mb-3">Inscrivez-vous à la dernière newsletter</p>
                    <!-- <div class="form">
                        <form action="">
                            <label for="">
                                <span>
                                    <input type="text" placeholder="Inscrivez-vous pour participer à nos adventures">
                                </span>
                            </label>
                            <input type="submit" value="S'inscrire →" class="wpcf7-form-control has-spinner wpcf7-submit btn-cus-nvt">
                        </form>
                    </div> -->
                    <div class="form">
                        <?php echo do_shortcode('[contact-form-7 id="8aeac92" title="section6_homepage"]') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>