<?php get_header(); ?>

<div class="container auto-padding">
    <div class="content p-3">
        <?php strip_tags(the_content()) ?>
    </div>
</div>

<?php get_footer(); ?>