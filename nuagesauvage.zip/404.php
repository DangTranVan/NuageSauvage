<?php get_header(); ?>

<main class="page-404 main loop-default-page">
	<div class="container text-center">
		<div class="entry-content py-5 my-5">
			<h1 class="fw-bold">Trang không tồn tại</h1>
			Trang bạn đang tìm kiếm không tồn tại.
		</div>
	</div>
</main>

<?php get_footer(); ?>
